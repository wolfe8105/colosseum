// ============================================================
// PM2 ECOSYSTEM CONFIG
// Keeps the bot army alive 24/7.
// Auto-restarts on crash, manages log rotation.
// Start: pm2 start ecosystem.config.js
// Monitor: pm2 monit
// Logs: pm2 logs colosseum-bots
// ============================================================
module.exports = {
  apps: [
    {
      name: 'colosseum-bots',
      script: 'bot-engine.js',
      node_args: '--max-old-space-size=256',  // Keep memory low on cheap VPS

      // Auto-restart
      autorestart: true,
      max_restarts: 50,
      min_uptime: '10s',
      restart_delay: 5000,           // 5s between restarts

      // Memory limit — restart if bot leaks memory
      max_memory_restart: '200M',

      // Logs
      error_file: './logs/pm2-error.log',
      out_file: './logs/pm2-out.log',
      merge_logs: true,
      log_date_format: 'YYYY-MM-DD HH:mm:ss',

      // Environment
      env: {
        NODE_ENV: 'production',
      },

      // Cron restart — restart fresh once a day at 4 AM EST
      // Clears in-memory caches, prevents stale connections
      cron_restart: '0 4 * * *',

      // Watch for file changes (useful during development, disable in prod)
      watch: false,
    },
  ],
};
