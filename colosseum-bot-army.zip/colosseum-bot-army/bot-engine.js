// ============================================================
// THE COLOSSEUM — BOT ENGINE
// Main orchestrator. Runs on cron schedules.
// Ties Leg 1 (Reactive) + Leg 2 (Proactive) together.
// Start with: pm2 start ecosystem.config.js
// ============================================================
const cron = require('node-cron');
const { config, validateConfig } = require('./bot-config');
const logger = require('./lib/logger');

// Leg 1 modules
const leg1Reddit = require('./lib/leg1-reddit');
const leg1Twitter = require('./lib/leg1-twitter');
const leg1Discord = require('./lib/leg1-discord');

// Leg 2 modules
const leg2NewsScanner = require('./lib/leg2-news-scanner');
const leg2DebateCreator = require('./lib/leg2-debate-creator');
const leg2TwitterPoster = require('./lib/leg2-twitter-poster');

// Stats
const { getBotStats } = require('./lib/supabase-client');

// ============================================================
// STARTUP
// ============================================================

async function boot() {
  console.log(`
  ╔══════════════════════════════════════════╗
  ║   🏛️  THE COLOSSEUM — BOT ARMY v1.0     ║
  ║   Fully Automated Growth Engine          ║
  ╚══════════════════════════════════════════╝
  `);

  // Validate config
  const { errors, warnings } = validateConfig();

  for (const w of warnings) {
    logger.warn(w);
  }

  if (errors.length > 0) {
    for (const e of errors) {
      logger.error(e);
    }
    logger.error('❌ Fix the above errors in .env and restart.');
    process.exit(1);
  }

  logger.info('✅ Config validated');
  logger.info(`Mode: ${config.dryRun ? '🧪 DRY RUN (no real posts)' : '🔴 LIVE'}`);
  logger.info(`Features: ${formatFlags()}`);

  // Start persistent connections
  await startPersistentBots();

  // Schedule cron jobs
  scheduleCronJobs();

  // Log stats every 6 hours
  scheduleStatsReport();

  logger.info('🚀 Bot army is operational');
}

function formatFlags() {
  const flags = [];
  if (config.flags.leg1Reddit) flags.push('L1-Reddit');
  if (config.flags.leg1Twitter) flags.push('L1-Twitter');
  if (config.flags.leg1Discord) flags.push('L1-Discord');
  if (config.flags.leg2News) flags.push('L2-News');
  if (config.flags.leg2Twitter) flags.push('L2-Twitter');
  if (config.flags.leg2DebateCreator) flags.push('L2-Debates');
  return flags.join(', ') || 'NONE (all disabled)';
}

// ============================================================
// PERSISTENT BOTS (always-on connections)
// ============================================================

async function startPersistentBots() {
  // Discord bot runs as a persistent WebSocket connection
  if (config.flags.leg1Discord) {
    try {
      await leg1Discord.start();
    } catch (err) {
      logger.error(`Discord bot failed to start: ${err.message}`);
    }
  }
}

// ============================================================
// CRON SCHEDULES
// ============================================================

function scheduleCronJobs() {
  // ----------------------------------------
  // LEG 1: REACTIVE — scan and reply
  // ----------------------------------------

  // Reddit: every 20 minutes
  if (config.flags.leg1Reddit) {
    cron.schedule('*/20 * * * *', async () => {
      try {
        await leg1Reddit.scanAndReply();
      } catch (err) {
        logger.error(`Leg 1 Reddit cron failed: ${err.message}`);
      }
    });
    logger.info('📅 Scheduled: Leg 1 Reddit — every 20 min');
  }

  // Twitter replies: every 30 minutes (only if Basic API)
  if (config.flags.leg1Twitter) {
    cron.schedule('*/30 * * * *', async () => {
      try {
        await leg1Twitter.scanAndReply();
      } catch (err) {
        logger.error(`Leg 1 Twitter cron failed: ${err.message}`);
      }
    });
    logger.info('📅 Scheduled: Leg 1 Twitter — every 30 min');
  }

  // Discord: always-on (no cron needed, handled by persistent connection)

  // ----------------------------------------
  // LEG 2: PROACTIVE — create content + post
  // ----------------------------------------

  // Full Leg 2 pipeline: every 15 minutes
  // Scan news → create debate pages → post to Twitter
  if (config.flags.leg2News) {
    cron.schedule('*/15 * * * *', async () => {
      try {
        await runLeg2Pipeline();
      } catch (err) {
        logger.error(`Leg 2 pipeline cron failed: ${err.message}`);
      }
    });
    logger.info('📅 Scheduled: Leg 2 Pipeline — every 15 min');
  }
}

// ============================================================
// LEG 2 PIPELINE
// ============================================================

async function runLeg2Pipeline() {
  logger.leg2('pipeline', 'Starting Leg 2 pipeline');

  // Step 1: Scan news for debate-worthy headlines
  const headlines = await leg2NewsScanner.scanNews(3);

  if (headlines.length === 0) {
    logger.leg2('pipeline', 'No fresh debate-worthy headlines found');
    return;
  }

  // Step 2: For each headline, create a debate page + post to Twitter
  for (const headline of headlines) {
    try {
      // Create the debate page in Supabase
      const debate = await leg2DebateCreator.createDebateFromHeadline(headline);

      if (!debate) {
        logger.leg2('pipeline', `Skipped headline (creation failed): "${headline.title.substring(0, 50)}..."`);
        continue;
      }

      // Post to Twitter (if enabled and in peak hours)
      if (config.flags.leg2Twitter) {
        // Mark as urgent if debate score is very high
        debate.urgent = headline.score >= 8;
        await leg2TwitterPoster.postHotTake(debate);
      }

      // Stagger between posts to look natural
      await sleep(15_000 + Math.random() * 30_000);
    } catch (err) {
      logger.error(`Leg 2 pipeline failed for headline: ${err.message}`);
    }
  }

  logger.leg2('pipeline', 'Leg 2 pipeline cycle complete');
}

// ============================================================
// STATS REPORT
// ============================================================

function scheduleStatsReport() {
  // Every 6 hours, log a stats summary
  cron.schedule('0 */6 * * *', async () => {
    try {
      const stats = await getBotStats(24);
      if (stats) {
        logger.info('📊 24h Bot Stats:');
        logger.info(`   Total actions: ${stats.total}`);
        logger.info(`   Leg 1: ${stats.leg1} | Leg 2: ${stats.leg2}`);
        logger.info(`   Success: ${stats.successes} | Failures: ${stats.failures}`);
        logger.info(`   By platform: ${JSON.stringify(stats.byPlatform)}`);
      }
    } catch (err) {
      logger.error(`Stats report failed: ${err.message}`);
    }
  });

  // Also log on startup
  setTimeout(async () => {
    const stats = await getBotStats(24);
    if (stats && stats.total > 0) {
      logger.info(`📊 Last 24h: ${stats.total} actions (${stats.leg1} L1, ${stats.leg2} L2)`);
    }
  }, 5000);
}

// ============================================================
// GRACEFUL SHUTDOWN
// ============================================================

async function shutdown(signal) {
  logger.info(`${signal} received — shutting down gracefully...`);

  // Stop Discord bot
  try {
    await leg1Discord.stop();
  } catch (e) { /* ignore */ }

  // Let cron jobs finish their current cycle
  await sleep(2000);

  logger.info('👋 Bot army shut down cleanly');
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('uncaughtException', (err) => {
  logger.error(`Uncaught exception: ${err.message}`);
  logger.error(err.stack);
  // Don't exit — PM2 will restart if we crash
});
process.on('unhandledRejection', (reason) => {
  logger.error(`Unhandled rejection: ${reason}`);
});

// ============================================================
// HELPERS
// ============================================================

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ============================================================
// GO
// ============================================================
boot().catch(err => {
  logger.error(`Boot failed: ${err.message}`);
  process.exit(1);
});
