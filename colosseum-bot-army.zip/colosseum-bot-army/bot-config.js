// ============================================================
// THE COLOSSEUM — BOT CONFIG
// Loads .env, validates all required values, exports config.
// Bot refuses to start if any PASTE_YOUR placeholder remains.
// ============================================================
require('dotenv').config();

const config = {
  // --- Supabase ---
  supabase: {
    url: process.env.SUPABASE_URL,
    serviceRoleKey: process.env.SUPABASE_SERVICE_ROLE_KEY,
  },

  // --- AI (Groq) ---
  groq: {
    apiKey: process.env.GROQ_API_KEY,
    model: 'llama-3.1-70b-versatile',   // free tier, fast, good enough
    maxTokens: 280,                       // tweet-length outputs
  },

  // --- Reddit ---
  reddit: {
    clientId: process.env.REDDIT_CLIENT_ID,
    clientSecret: process.env.REDDIT_CLIENT_SECRET,
    username: process.env.REDDIT_USERNAME,
    password: process.env.REDDIT_PASSWORD,
    userAgent: process.env.REDDIT_USER_AGENT,
    // Subreddits to monitor — start with argument-heavy ones
    subreddits: [
      'unpopularopinion', 'changemyview', 'AmItheAsshole',
      'TrueOffMyChest', 'nba', 'nfl', 'politics',
      'entertainment', 'movies', 'music',
      'relationship_advice', 'sports', 'MMA',
    ],
    // How many posts to scan per subreddit per cycle
    postsPerScan: 10,
    // Min comment score to consider replying to (avoid buried threads)
    minScore: 5,
    // Max replies per cycle across all subreddits
    maxRepliesPerCycle: 8,
    // Cooldown between replies (ms) — don't look like a bot
    replyCooldownMs: 120_000,  // 2 minutes
  },

  // --- Twitter / X ---
  twitter: {
    apiKey: process.env.TWITTER_API_KEY,
    apiSecret: process.env.TWITTER_API_SECRET,
    accessToken: process.env.TWITTER_ACCESS_TOKEN,
    accessSecret: process.env.TWITTER_ACCESS_SECRET,
    // Leg 2: how many hot takes per day
    maxPostsPerDay: 8,
    // Peak posting hours (EST) — when engagement is highest
    peakHoursEST: [7, 8, 9, 12, 13, 17, 18, 19, 20, 21],
  },

  // --- Discord ---
  discord: {
    botToken: process.env.DISCORD_BOT_TOKEN,
    // Keywords that signal an argument is happening
    argumentKeywords: [
      'you\'re wrong', 'that\'s bs', 'no way', 'fight me',
      'hot take', 'unpopular opinion', 'worst take', 'terrible take',
      'disagree', 'overrated', 'underrated', 'mid',
      'cap', 'ratio', 'L take', 'W take', 'delusional',
    ],
    // Cooldown per channel (ms) — don't spam
    channelCooldownMs: 600_000,  // 10 minutes
  },

  // --- Proxy ---
  proxy: {
    url: process.env.PROXY_URL === 'NONE' ? null : process.env.PROXY_URL,
  },

  // --- App ---
  app: {
    baseUrl: process.env.APP_BASE_URL || 'https://colosseum-six.vercel.app',
    debateLandingPath: process.env.DEBATE_LANDING_PATH || '/colosseum-debate-landing.html',
  },

  // --- Feature Flags ---
  flags: {
    leg1Reddit: process.env.LEG1_REDDIT_ENABLED === 'true',
    leg1Twitter: process.env.LEG1_TWITTER_ENABLED === 'true',
    leg1Discord: process.env.LEG1_DISCORD_ENABLED === 'true',
    leg2News: process.env.LEG2_NEWS_ENABLED === 'true',
    leg2Twitter: process.env.LEG2_TWITTER_ENABLED === 'true',
    leg2DebateCreator: process.env.LEG2_DEBATE_CREATOR_ENABLED === 'true',
  },

  // --- Operational ---
  logLevel: process.env.LOG_LEVEL || 'info',
  dryRun: process.env.DRY_RUN === 'true',

  // --- News Sources (Leg 2) ---
  newsSources: [
    { name: 'Google News - Top',      url: 'https://news.google.com/rss?hl=en-US&gl=US&ceid=US:en' },
    { name: 'Google News - Sports',    url: 'https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNRFp1ZEdvU0FtVnVHZ0pWVXlnQVAB?hl=en-US&gl=US&ceid=US:en' },
    { name: 'Google News - Politics',  url: 'https://news.google.com/rss/topics/CAAqIQgKIhtDQkFTRGdvSUwyMHZNRFZ4ZERBU0FtVnVLQUFQAQ?hl=en-US&gl=US&ceid=US:en' },
    { name: 'Google News - Entertainment', url: 'https://news.google.com/rss/topics/CAAqJggKIiBDQkFTRWdvSUwyMHZNREpxYW5RU0FtVnVHZ0pWVXlnQVAB?hl=en-US&gl=US&ceid=US:en' },
    { name: 'ESPN - Top',             url: 'https://www.espn.com/espn/rss/news' },
    { name: 'ESPN - NBA',             url: 'https://www.espn.com/espn/rss/nba/news' },
    { name: 'ESPN - NFL',             url: 'https://www.espn.com/espn/rss/nfl/news' },
  ],

  // --- Topic Categories (maps to app sections) ---
  topicCategories: {
    politics: { label: 'Politics', tier: 1 },
    sports:   { label: 'Sports',   tier: 1 },
    entertainment: { label: 'Entertainment', tier: 2 },
    couples:  { label: 'Couples Court', tier: 2 },
    music:    { label: 'Music',    tier: 3 },
    movies:   { label: 'Movies/TV', tier: 3 },
  },
};

// ============================================================
// STARTUP VALIDATION — refuse to run with placeholders
// ============================================================
function validateConfig() {
  const errors = [];
  const warnings = [];

  // Always required
  const required = [
    ['SUPABASE_SERVICE_ROLE_KEY', config.supabase.serviceRoleKey],
    ['GROQ_API_KEY', config.groq.apiKey],
  ];

  // Conditionally required based on enabled flags
  if (config.flags.leg1Reddit) {
    required.push(
      ['REDDIT_CLIENT_ID', config.reddit.clientId],
      ['REDDIT_CLIENT_SECRET', config.reddit.clientSecret],
      ['REDDIT_USERNAME', config.reddit.username],
      ['REDDIT_PASSWORD', config.reddit.password],
    );
  }

  if (config.flags.leg2Twitter || config.flags.leg1Twitter) {
    required.push(
      ['TWITTER_API_KEY', config.twitter.apiKey],
      ['TWITTER_API_SECRET', config.twitter.apiSecret],
      ['TWITTER_ACCESS_TOKEN', config.twitter.accessToken],
      ['TWITTER_ACCESS_SECRET', config.twitter.accessSecret],
    );
  }

  if (config.flags.leg1Discord) {
    required.push(['DISCORD_BOT_TOKEN', config.discord.botToken]);
  }

  for (const [name, value] of required) {
    if (!value || value.includes('PASTE_YOUR')) {
      errors.push(`❌ ${name} is missing or still a placeholder`);
    }
  }

  // Warnings (non-fatal)
  if (config.flags.leg1Twitter) {
    warnings.push('⚠️  Leg 1 Twitter (scanning) requires Basic API ($100/mo). Free tier is write-only.');
  }

  if (!config.proxy.url && (config.flags.leg1Reddit || config.flags.leg1Twitter)) {
    warnings.push('⚠️  No proxy configured — IP bans more likely on Reddit/X');
  }

  if (config.dryRun) {
    warnings.push('🧪 DRY_RUN is ON — bot will log actions but not post anything');
  }

  return { errors, warnings };
}

module.exports = { config, validateConfig };
